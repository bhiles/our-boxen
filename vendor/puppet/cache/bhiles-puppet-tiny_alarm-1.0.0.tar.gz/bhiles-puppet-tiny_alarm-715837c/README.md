# Tiny Alarm Puppet Module for Boxen

[![Build Status](https://travis-ci.org/bhiles/puppet-tiny_alarm.png)](https://travis-ci.org/bhiles/puppet-tiny_alarm)

[Tiny Alarm](http://plumamazing.com/mac/tinyalarm) lives in your toolbar and lets you easily set timers.

## Usage

```puppet
include tiny_alarm
```

## Required Puppet Modules

None.

## Developing

Write code.

Run `script/cibuild`.
